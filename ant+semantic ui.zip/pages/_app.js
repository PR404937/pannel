// import 'bootstrap/dist/css/bootstrap.min.css';
// import '../scss/main.scss'
// import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";


// if (typeof window === 'undefined') {
//   global.window = {}
// }

// function MyApp({ Component, pageProps }) {
//   return <Component {...pageProps} />
// }

// export default MyApp



import App from 'next/app'
import React from 'react'
import {Provider} from 'react-redux'
import {createWrapper} from 'next-redux-wrapper'
import store from '../store/store'
import Body from './components/Body'

import 'antd/dist/antd.css';
import 'semantic-ui-css/semantic.min.css'
import './style.css'

class MyApp extends App {
  render(){
    const {Component,pageProps} = this.props;
    return(
      <Provider store={store}>
          <Body>
          <Component {...pageProps}></Component>
          </Body>
      </Provider>
    )
  }
}


const makestore = () => store;
const wrapper = createWrapper(makestore);

export default wrapper.withRedux(MyApp);

