import React, { Component } from 'react'
import { Layout, Menu,Avatar,Tooltip,Input  } from 'antd';
import {
  PieChartOutlined,
  UserOutlined,
  CalendarOutlined ,
  MessageOutlined ,
  SettingOutlined ,
  TabletOutlined ,
  MenuFoldOutlined ,
  CloudUploadOutlined,
  SearchOutlined 
 
} from '@ant-design/icons';


import Link from 'next/link'

const { Header, Footer, Sider } = Layout;
const { SubMenu } = Menu;
const text = <span>This is profile</span>

export default class Body extends Component {
 
    state = {
        collapsed: false,
      
      };
      
      toggle = () => {
        this.setState({
          collapsed: !this.state.collapsed,
         
        });
      };

      componentDidMount(){
      }

      componentDidUpdate(){
        
      }
    
      render() {
        
        
        return (
          <Layout style={{ minHeight: '100vh', }}>
            <Sider trigger={null} collapsible collapsed={this.state.collapsed} >
              <div className="logo" style={{marginTop:"20px",marginBottom:"25px"}}>
             <center>
             <Tooltip placement="right" title={text}>
             <Avatar icon={<UserOutlined />}  />
      </Tooltip>
            
             </center>
             
        
              </div>
              <Menu theme="dark" defaultSelectedKeys='/' mode="inline" style={{fontSize:"18px", cursor: "pointer"}}>
                <Menu.Item key="/" icon={<PieChartOutlined />}>
                    <Link href='/' >Dashboard</Link>
                </Menu.Item>

                <Menu.Item key="/notes" icon={<PieChartOutlined />}>
                    <Link href='/notes'>Notes</Link>
                </Menu.Item>
                
                <SubMenu key="sub1" icon={<MessageOutlined />} title="message" > 
                  <Menu.Item key="/packages"><Link href='/packages'>All</Link></Menu.Item>
                  <Menu.Item key="/packages/create"><Link href='/packages/create' className="ant-menu-item-only-child">Create</Link></Menu.Item>
                </SubMenu>
              
                <Menu.Item key="/setting" icon={<SettingOutlined />}>
                    <Link href='/setting'>Setting</Link>
                </Menu.Item>
                <Menu.Item key="/calender" icon={<CalendarOutlined />}>
                    <Link href='/calender'>Notes</Link>
                </Menu.Item>
                <Menu.Item key="/callender" icon={<TabletOutlined />}>
                    <Link href='/callender'>Callender</Link>
                </Menu.Item>
                
                <Menu.Item key="/updatepro" icon={<CloudUploadOutlined />} style={{marginTop:"300px",backgroundColor:"",color:"white"}}>
               
                    <Link href='/updatepro' style={{fontSize:"19px"}} > UPDATE PRO </Link>
                </Menu.Item>
              
          
          
               
              </Menu>

       
            </Sider>
            <Layout className="site-layout">
            <Header className="site-layout-background" style={{ padding: 0 ,marginLeft:"30px",fontSize:"20px"}}>

           
           
            {React.createElement(this.state.collapsed ? MenuFoldOutlined : MenuFoldOutlined, {
              className: 'trigger',
              onClick: this.toggle,
            })}
                   <Input size="large" placeholder="search here..." prefix={<SearchOutlined />}  style={{width:"260px",marginLeft:"60px",height:"30px",outline:"none"}} />
          </Header>
              
              {this.props.children}

              <Footer style={{ textAlign: 'center' }}>Qtonix ©2020</Footer>
            </Layout>
          </Layout>
        );
      }
     
}
